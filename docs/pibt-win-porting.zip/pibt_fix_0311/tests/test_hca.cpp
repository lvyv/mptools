#include <hca.hpp>

#include "gtest/gtest.h"

int optreset;
int optopt = '?';
int optind = 1;
int opterr = 1;
char *optarg;

int getopt_long(int nargc, char *const *nargv, const char *options,
                const struct option *long_options, int *idx)
{
  return (
      getopt_internal(nargc, nargv, options, long_options, idx, FLAG_PERMUTE));
}

int getopt(int nargc, char *const *nargv, const char *options)
{
  /*
   * We don't pass FLAG_PERMUTE to getopt_internal() since
   * the BSD getopt(3) (unlike GNU) has never done this.
   *
   * Furthermore, since many privileged programs call getopt()
   * before dropping privileges it makes sense to keep things
   * as simple (and bug-free) as possible.
   */
  return (getopt_internal(nargc, nargv, options, NULL, NULL, 0));
}

TEST(HCA, solve)
{
  auto P = MAPF_Instance("../tests/instances/example.txt");
  auto solver = std::make_unique<HCA>(&P);
  solver->solve();

  ASSERT_TRUE(solver->succeed());
  ASSERT_TRUE(solver->getSolution().validate(&P));
}
